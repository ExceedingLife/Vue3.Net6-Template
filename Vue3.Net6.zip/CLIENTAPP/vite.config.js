import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

/* Dev Cert */
import mkcert from 'vite-plugin-mkcert'
// Added: mkcert() + server { https: true }
/* Dev Cert End */

// https://vitejs.dev/config/
export default defineConfig({
	plugins: [vue(), mkcert()],
	server: {
		port: 3000,
		https: true,
		strictPort: true,
		proxy: {
			'/api': {
				target: "https://localhost:7031",
				changeOrigin: true,
				secure: false,
				rewrite: (path) => path.replace(/^\/api/, '/api')
			}
		}
	}
})
